import React from 'react';
import { Container, Card, Row, Col } from 'react-bootstrap';
export default function Jobs(){
  const plumberJobs=[{title:'Fix kitchen leak',loc:'Near you',dist:'1.2 km'},{title:'Unclog drain',loc:'Near you',dist:'2.1 km'}];
  const electricianJobs=[{title:'Repair wiring',loc:'Near you',dist:'1.8 km'},{title:'Install light',loc:'Near you',dist:'3.0 km'}];
  return (
    <Container className='container-main'>
      <h3>Plumber Jobs</h3>
      <Row>{plumberJobs.map((j,i)=> (<Col key={i} md={6}><Card className='mb-2'><Card.Body><Card.Title>{j.title}</Card.Title><Card.Text>{j.loc} • {j.dist}</Card.Text></Card.Body></Card></Col>))}</Row>
      <h3 className='mt-3'>Electrician Jobs</h3>
      <Row>{electricianJobs.map((j,i)=> (<Col key={i} md={6}><Card className='mb-2'><Card.Body><Card.Title>{j.title}</Card.Title><Card.Text>{j.loc} • {j.dist}</Card.Text></Card.Body></Card></Col>))}</Row>
    </Container>
  );
}
