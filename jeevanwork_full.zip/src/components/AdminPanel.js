import React, {useEffect, useState} from 'react';
import { Container, Form, Button, Table } from 'react-bootstrap';
import { auth, db, storage } from '../firebase';
import { signOut } from 'firebase/auth';
import { collection, addDoc, getDocs, deleteDoc, doc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

export default function AdminPanel(){
  const [workers, setWorkers] = useState([]);
  const [form, setForm] = useState({name:'',role:'Plumber',phone:'',bio:'',location:''});
  const [file, setFile] = useState(null);
  useEffect(()=>{ loadWorkers(); },[]);
  async function loadWorkers(){
    const snap = await getDocs(collection(db,'workers'));
    setWorkers(snap.docs.map(d=>({id:d.id,...d.data()})));
  }
  async function handleAdd(e){
    e.preventDefault();
    try{
      let url='';
      if(file){
        const r = ref(storage, 'workers/'+Date.now()+'_'+file.name);
        const snap = await uploadBytes(r, file);
        url = await getDownloadURL(snap.ref);
      }
      await addDoc(collection(db,'workers'), {...form, photoUrl:url});
      setForm({name:'',role:'Plumber',phone:'',bio:'',location:''});
      setFile(null);
      await loadWorkers();
      alert('Added');
    }catch(e){ alert(e.message); }
  }
  async function handleDelete(id){
    if(!window.confirm('Delete?')) return;
    await deleteDoc(doc(db,'workers',id));
    await loadWorkers();
  }
  function handleLogout(){ signOut(auth); window.location='/'; }
  return (
    <Container className='container-main'>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}><h3>Admin Panel</h3><Button variant='secondary' onClick={handleLogout}>Logout</Button></div>
      <Form onSubmit={handleAdd} className='mb-3'>
        <Form.Control className='mb-2' placeholder='Name' value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required />
        <Form.Select className='mb-2' value={form.role} onChange={e=>setForm({...form,role:e.target.value})}>
          <option>Plumber</option><option>Electrician</option>
        </Form.Select>
        <Form.Control className='mb-2' placeholder='Phone' value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} />
        <Form.Control className='mb-2' placeholder='Bio' value={form.bio} onChange={e=>setForm({...form,bio:e.target.value})} />
        <Form.Control className='mb-2' placeholder='Location' value={form.location} onChange={e=>setForm({...form,location:e.target.value})} />
        <Form.Control className='mb-2' type='file' onChange={e=>setFile(e.target.files[0])} />
        <Button type='submit'>Add Worker</Button>
      </Form>
      <h5>Existing Workers</h5>
      <Table bordered>
        <thead><tr><th>Name</th><th>Role</th><th>Phone</th><th>Actions</th></tr></thead>
        <tbody>
          {workers.map(w=>(
            <tr key={w.id}>
              <td>{w.name}</td><td>{w.role}</td><td>{w.phone}</td>
              <td><Button variant='danger' size='sm' onClick={()=>handleDelete(w.id)}>Delete</Button></td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  );
}
