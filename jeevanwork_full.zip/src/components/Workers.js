import React, {useEffect, useState} from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../firebase';

export default function Workers(){
  const [workers, setWorkers] = useState([]);
  useEffect(()=>{
    async function load(){
      try{
        const snap = await getDocs(collection(db,'workers'));
        const arr = snap.docs.map(d=>({id:d.id,...d.data()}));
        setWorkers(arr);
      }catch(e){ console.error(e); }
    }
    load();
  },[]);
  const plumbers = workers.filter(w=>w.role==='Plumber');
  const electricians = workers.filter(w=>w.role==='Electrician');
  return (
    <Container className='container-main'>
      <h3>Plumbers</h3>
      <Row>{plumbers.map(w=>(
        <Col md={6} key={w.id}><Card className='mb-2'><Card.Body><Card.Title>{w.name}</Card.Title><Card.Text>{w.bio}</Card.Text><Card.Text>{w.phone}</Card.Text></Card.Body></Card></Col>
      ))}</Row>
      <h3 className='mt-3'>Electricians</h3>
      <Row>{electricians.map(w=>(
        <Col md={6} key={w.id}><Card className='mb-2'><Card.Body><Card.Title>{w.name}</Card.Title><Card.Text>{w.bio}</Card.Text><Card.Text>{w.phone}</Card.Text></Card.Body></Card></Col>
      ))}</Row>
    </Container>
  );
}
