import React from 'react';
import { Container, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
export default function Home(){
  return (
    <Container className='container-main'>
      <div style={{textAlign:'center',padding:20,background:'#1a73e8',color:'#fff',borderRadius:6}}>
        <h2>JeevanWork - Future of Skill Based Hiring</h2>
      </div>
      <div style={{marginTop:20}}>
        <div className='card p-3 mb-3'>
          <h4>Find Work</h4>
          <p>Search jobs based on your skills, rating & verified score.</p>
          <Link to='/jobs'><Button variant='primary'>Search Jobs</Button></Link>
        </div>
        <div className='card p-3 mb-3'>
          <h4>Hire Workers</h4>
          <p>Hire plumbers, electricians, painters, helpers & more.</p>
          <Link to='/workers'><Button variant='primary'>Hire Now</Button></Link>
        </div>
        <div className='card p-3 mb-3'>
          <h4>Skill Score System</h4>
          <p>Every worker & job seeker gets a verified Work Score based on skills, behavior & performance.</p>
        </div>
      </div>
    </Container>
  );
}
