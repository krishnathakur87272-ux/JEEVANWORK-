import React, {useState} from 'react';
import { Container, Form, Button } from 'react-bootstrap';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase';
import { useNavigate } from 'react-router-dom';

export default function AdminLogin(){
  const [email,setEmail]=useState('');
  const [pass,setPass]=useState('');
  const nav = useNavigate();
  const handle = async (e)=>{
    e.preventDefault();
    try{
      await signInWithEmailAndPassword(auth,email,pass);
      nav('/admin/panel');
    }catch(err){ alert('Login failed: '+err.message); }
  };
  return (
    <Container className='container-main'>
      <h3>Admin Login</h3>
      <Form onSubmit={handle} className='mb-3'>
        <Form.Control className='mb-2' placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} />
        <Form.Control className='mb-2' type='password' placeholder='Password' value={pass} onChange={e=>setPass(e.target.value)} />
        <Button type='submit'>Login</Button>
      </Form>
      <p>Use your admin account to access the panel.</p>
    </Container>
  );
}
